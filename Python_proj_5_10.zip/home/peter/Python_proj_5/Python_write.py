with open ("file.txt", "w") as f:
    f.write("A")
    f.write("A")